/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Mar 27 2021
Assignment #:	Project 04
Status: 		Completed
Language:		C++
Help:           I usually use Class PowerPoint, ClassWorks projects, Book, and Google. 
-------------------------------------------------------------------------
Comments:
This program will get the amount of food eaten by 4 monkeys during the week from user. 
Then creat a table to show the amount of ood each monky ate at each day of the week.
At the end it will calculate the average of food eaten by all monkeys during a week.
Also will find the Max and Min amount of food that was eaten betwwen all monkeys.
*/

#include <iostream>				// for cin, cout, endl
#include <iomanip>
#include <string>
using namespace std;

// Declaration of function prototypes

// This function will get the amount of food from user
float getData(string );
//This function finds the max amount of food that was eaten 
float getHighest(float poundEat[][7]);
//This function finds the min amount of food that was eaten 
float getLeast(float poundEat[][7]);
//This function prints the results
void printResult(float & ,float & , float &);

//Main function
int main()
{
	//To have 2 decimal for numbers
	cout << fixed << showpoint << setprecision(2) << endl;
	//Decleration of variables
	int MONKEY = 4;
	int DAY = 7;
	float value;
	string weekDay[DAY];
	float poundEat [MONKEY] [7];
	float max;
	float min;
	float averageEat;
	float totalEat = 0;
	//Using 2 for functions to get the amount of foof for each monkey on all days of the week
	for ( int rows = 0; rows < MONKEY; rows++)
	{
		for ( int cols = 0; cols < DAY; cols++)
		{
			//Declare an array to store the 7 days of a week with name
			string weekDay[7] = {"Sun: ", "Mon: ", "Tue: ", "Wed: ", "Thu: ", "Fri: ", "Sat: "};
			cout << "Enter pounds of food eaten by monkey " << rows +1 <<" on " << weekDay[cols];
			//This function gets data from user
			poundEat[rows][cols] = getData("");
		}
		cout << endl;	
	}
	cout << "\nPounds of Food Eaten by Monkey and Day of Week\n";
	cout << "\nMonkey" <<'\t'<<  "Sun" <<'\t'<< "Mon" <<'\t'<< "Tue" <<'\t'<< "Wed" <<'\t'<< "Thu" <<'\t'<< "Fri" <<'\t'<< "Sat" << endl;
	//Using 2 for function to print the data in a 4*7 table 
	for ( int rows = 0; rows < MONKEY; rows++)
	{
		cout << rows + 1 << '\t';
		for ( int cols = 0; cols < DAY; cols++)
		{
			cout <<   poundEat[rows][cols] << '\t';
			//This function calculate summ of all the food eaten by all monkeys
			totalEat = totalEat + poundEat [rows][cols];
		}
		cout <<'\n' ;	
	}
	//This function calculate the average of all food eaten by all monkeys
	averageEat = totalEat / (MONKEY * DAY);
	//Using function to find the max amount of food that was eaten
	max = getHighest(poundEat);
	//Using function to find the min amount of food that was eaten
	min = getLeast(poundEat);
	//Using function to print result
	printResult(min, max, averageEat);
	
	system("PAUSE");
    return 0;
} // end of main()

//This function prints the results
void printResult(float & min, float & max, float & averageEat)
{
	cout <<"\nThe average food eaten per day by all monkeys :  " << averageEat << "   pounds" << endl;
	cout <<"The least amount of food eaten by any monkey  :  " << min << "   pounds" << endl;
	cout <<"The highest amount of food eaten by any monkey:  " << max << "   pounds\n" << endl;	
}//End of printResult
//This function finds the min amount of food that was eaten 
float getLeast(float poundEat[3][7])
{
  float least = poundEat[0][0];

   for ( int rows = 0; rows < 3; rows++)
	{  
		for ( int cols = 0; cols < 7; cols++)
		{
			if (poundEat[rows][cols] < least)
      	 	least = poundEat[rows][cols];
		}
	
	}
    return least;
 }//End of getLeast
 //This function finds the max amount of food that was eaten 
float getHighest(float poundEat[3][7])
{
  float highest = poundEat[0][0];

   for ( int rows = 0; rows < 3; rows++)
	{  
		for ( int cols = 0; cols < 7; cols++)
		{
			if (poundEat[rows][cols] > highest)
      	 	highest = poundEat[rows][cols];
		}
	
	}
    return highest;
 }//End of getHighest
// This function gets integer input from user
float getData(string prompt)
{
	float value;
	cout << prompt;
	cin >> value;
	while (value < 0)
	{
		cout << "Please enter positive amount\n";
		cin >> value;
	}
	
	return value;
}//End of get data
