/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Apr 25 2021
Assignment #:	Project 08
Status: 		Completed
Language:		C++
Help:           I usually use Class PowerPoint, ClassWorks projects, Book, and Google. 
-------------------------------------------------------------------------
Comment: This program will get the date from user and print it in 3 ways as "d/m/y" and "d monthName y" and "monthName d, y".
If the input is not valid the program use instructor to set date as default which is defined by instructor to 1/1/2020.
Days are between 1-31, Month is between 1-12 and year is between 1950-2020 
*/
#include <string>
#include <iostream>
#include <cmath>

using namespace std;
//Decleration of class Date
class Date
{
	private:
		int day;
		int month;
		int year;
		//This methode will return the name og the month
		string getMonthName(int month)
		{
			string name;
			string monthName[] = {"January","February","March","April","May","June","July","August","September","October","November","December"};
			name = monthName[month-1];
			return name;	
		}//End of getMonthName()
			
	public:
		//Using constructor to set the default date
		Date()	
		{
			day = 1;
			month = 1;
			year = 2020;
		}// End of constructor
		//This method will set the day, month and year
		void setDate(int userDay, int userMonth, int userYear)
        {
        	//Using if to check if data is not valid to set the date as defualt by using constructor
            if (userDay <1 || userDay > 31 || userMonth <1 || userMonth > 12 || userYear <1950 || userYear > 2020)
            {
           		day = Date().day;
           		month = Date().month;
           		year = Date().year;
			}
			else
			{
				day = userDay;
				month = userMonth;
				year = userYear;
			}
        }//End of setDate()
        //Using getter to use the data as needed (in this case for print result)
        int getDay(void)
		{
			return day ;
		}//End of getDay()
		int getMonth(void)
		{
			return month ;
		}//End of getMonth()
		int getYear(void)
		{
			return year ;
		}//End of getYear()
		//This method will print the result
		void printDate()
		{
			cout << "*******************************\n";
			cout << getDay() << "/" << getMonth() << "/" << getYear()<< endl;
			cout << getMonthName(getMonth()) << " " <<  getDay() << ", " << getYear() << endl;
			cout << getDay() << " " << getMonthName(getMonth()) << " " << getYear()<< endl;
			cout << "*******************************\n"; 	
		}//End of printDate()		
};
//Prototype decleration
//The next three function will be used to get Day, Month and Year
int getDay(string prompt);
int getMonth(string prompt);
int getYear(string prompt);
//Main function
int main()
{
	Date userDate;
	int day;
	int month;
	int year;
	char reTry;
	cout << "This Program will print date in three formats.\nValid enteries are:\nDay: 1-31, Month: 1-12 and Year: 1950-2020.\n"
	     << "If not valid, date will be 1/1/2020 by default.\nProram accepts only numeric intery.\n";
	//Next three function will be used to get the Day, Month and Year from user
	day = getDay("\nEnter Day: ");
	month = getMonth("Enter Month: ");
	year = getYear("Enter year: ");
	//Calling method from class to set Day, Month and Year
	userDate.setDate(day, month, year);
	//Calling method to print the result
	userDate.printDate();
	cout<< "Do you want to try again? Y/N ";
	cin >> reTry;
	reTry = toupper(reTry);
	//Using while loop  to check if user wants to try the program again without restarting the program
	while (reTry == 'Y')
	{
	day = getDay("\nEnter Day: ");
	month = getMonth("Enter Month: ");
	year = getYear("Enter year: ");
	userDate.setDate(day, month, year);
	userDate.printDate();
	cout<< "Do you want to try again? Y/N ";
	cin >> reTry;
	reTry = toupper(reTry);
	}
	cout << "Good Bye!\n";
		
	system("PAUSE");
    return 0;
}//End of main()
//To get the day from user
int getDay(string prompt)
{
    int day;
    cout << prompt;
    cin >> day;
    //Using while loop the check the validity of data
    while (cin.fail())
	{
    	cin.clear();
    	cin.ignore();
    	fflush(stdin);
    	cout << "Invalid, Enter Day: ";
    	cin >> day;
	}
    return day;
}//End of getDay()
//To get the month from user
int getMonth(string prompt)
{
    int month;
    cout << prompt;
    cin.clear();
    cin.ignore();
    fflush(stdin);
    cin >> month;
    //Using while loop the check the validity of data
    while (cin.fail())
	{
    	cin.clear();
    	cin.ignore();
    	fflush(stdin);
    	cout << "Invalid, Enter Month: ";
    	cin >> month;
	}
    return month;
}//End of getMonth()
//To get the year from user
int getYear(string prompt)
{
    double year;
    cout << prompt;
    cin.clear();
    cin.ignore();
    fflush(stdin);
    cin >> year;
    //Using while loop the check the validity of data
    while (cin.fail())
	{
    	cin.clear();
    	cin.ignore();
    	fflush(stdin);
    	cout << "Invalid, Enter Year: ";
    	cin >> year;
	}
    return year;
}//End of getYear()