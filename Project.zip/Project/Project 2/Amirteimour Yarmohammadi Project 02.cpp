/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Mar 06 2021
Assignment #:	Project 02
Language:		C++
Status: 		Completed
-------------------------------------------------------------------------
Comments:
This program balance a checkbook at the end of the month.
The program will have the user enter the initial balance followed by a series of transactions. 
For each transaction, first  the user enter a transaction type. The valid transaction types are:
C - process a check.
D - process a deposit.
E - perform end of month processing and exit the program.
For checks and deposits, the user will be prompted to enter the transaction amount.
*/

#include <iostream>				// for cin, cout, endl
#include <iomanip>
#include <string>
using namespace std;


// declaration of function prototypes
float getInicialBalance(string);
char getCommand(string);     
float getAmount(string);

int main()
{
	// decleration of variables
	cout<< fixed << setprecision(2);          // to add two decimal to the numbers
	float initialBalance;
	char command;
	float enterAmount;
	float currentBalance;
	float tallyBalance;
	float serviceCharge;
	float endBalance;
	
	initialBalance = getInicialBalance("Please Enter Your Initial Balance: ");   //This function will get the initial balance
	tallyBalance = initialBalance;                                   
	serviceCharge = 0;
	command = getCommand("Please Enter (D) for Deposit, (C) for Check, (E) for Exit: "); // pre-read
	
	while (command == 'D' || command == 'C')                           // using the loop with C or D until user enter E which is the end of the transaction
	{
		if (command == 'D')                                           // Using if function to choose between D and C and their respective transaction
		{
			cout << "Depositing Checks" << endl;
			enterAmount = getAmount("Enter the Deposit Amount: ");    // using function to get the user's entery
			cout << "Processing Deposit For: $" << enterAmount << endl;  
			tallyBalance = tallyBalance + enterAmount;                // Calculating the current balance after each transaction, using the while function
			cout << "\nProcessed...\n";
			cout<<"Your Current Balance is: $" << tallyBalance <<endl; 
			cout << "Total Service Fee is: $"<< serviceCharge << endl;
			cout << "-----------------------------------------------------------------------"<< endl;
		}
		else
		{
			cout << "Cashing Checks" << endl;
			enterAmount = getAmount("Enter the Check Amount: ");      // using function to get the user's entery
			cout << "Processing check for: $" << enterAmount << endl;
			tallyBalance = tallyBalance - enterAmount;                 // Calculating the current balance after each transaction, using the while function
			serviceCharge = serviceCharge + 0.25;                      // Calculating the sum of all service charges  after each transaction, using the while function
			cout << "\nProcessed...\n";
			cout<<"Your Current Balance is: $" << tallyBalance <<endl;
			cout << "Total Service Fee is: $"<< serviceCharge << endl;
			cout << "-----------------------------------------------------------------------"<< endl;
			
		}
		
		command = getCommand("Please Enter (D) for Deposit, (C) for Check, (E) for Exit: ");     // update-read
	}
	endBalance = tallyBalance - serviceCharge;                 // Calculating the End of the month balance 
	cout << "Transaction Is Done" << endl;
	cout << "Your Service Charge for Checks Is: $" << serviceCharge << endl;
	cout << "Your End of the Month Balance Is: $" << endBalance << endl;
	cout << "-----------------------------------------------------------------------"<< endl;
	
	system("PAUSE");
    return 0;
} // end of main()

float getInicialBalance(string prompt)    ////This function will get the initial balance
{
	float balance;
	cout << prompt ;
	cin >> balance;
	cout << "You Entered: $" << balance << endl;
	while (balance < 0)                                // to check if the number is negetive
	{
		cout << "Please Enter 0 or a Positive Number"<< endl;
		cin >> balance;
		cout << "You Entered: $" << balance << endl;
	}
	cout<<"Your Initial Balance is: $" << balance <<endl;   
	cout << "-----------------------------------------------------------------------"<< endl;
	return balance;
}  //End of getInicialBalance

float getAmount(string prompt)         // this function will get the users entery for check or deposit and only return numbers >= 0
{
	float amount;
	cout << prompt;
	cin >> amount;
	while (amount <0)                 // to check if the number is negetive
	{
	cout << "Please Enter Positive Amount: ";
	cin >> amount;
	}
	return amount;
	
} // end of getAmount()

// getCommand() will get users input for a character command
// only returns D, C, or E
char getCommand(string prompt)
{
	char command;
	cout << prompt;
	cin >> command; // pre-read
	command = toupper(command);
	
	while (command != 'D' && command != 'E' && command != 'C')
	{
		cout << "Wrong Entery" << endl;
		cout << prompt;
		cin >> command; // update-read
		command = toupper(command);
	}
	
	return command;
} // end of getCommand()

