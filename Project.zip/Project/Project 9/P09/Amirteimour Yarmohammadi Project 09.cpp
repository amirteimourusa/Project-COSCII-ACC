/* 
Name:     		Amirteimour Yarmohammadi
Date: 			May 02 2021
Assignment #:	Project 09
Status: 		Completed
Language:		C++
-------------------------------------------------------------------------
Comments
This program will read the master file to get employee information and then another file to get the hours that each employee worked,
create class, populate the class and create some objects with the data from the file.
This program will read the trans10.txt file and find the employee by the employee ID
and calcuate the gross pay, net pay, tax and insurance and  Store them in the Employee class.
*/
#include <iostream>                // for cin, cout, endl
#include <fstream>
#include <iomanip>
#include <cstring>
#include <string>
using namespace std;
//Decleration of class employee
class Employee
    {
        private:
            int ID;
            int employeeType;
            int dependant;
            string gender;
            string name;
            float hourlyPay;
            float hoursWorked;
             
        public:
        	//Method to set ID, name, pay rate, dependant, employee type, M/F after reading the info from file
            void set(int, string, float, int, int, string);
            //	//Method to set hours worked after reading the info from file
            void setHoursWorked(float);
            //Using getter to use the data as needed (in this case for print into a file)
            int getID();
            string getName();
            int getDependant();
            int getEmployeeType();
            string getGender();
            float getHourlyPay();
            float getHoursWorked();
            float getGrossPay();
            float getNetPay();          
    }; // end of class Employee
// setter for employee data attributes 
void Employee::set(int newID, string newName, float newHourlyPay,  int numberDependant, int newType, string employeeGender )
{
    ID = newID;
    name = newName;
    gender = employeeGender;
    dependant = numberDependant;
    employeeType = newType;
    hourlyPay = newHourlyPay;
} // end of setter for employee data attributes
//setter to set hours worked from file
void Employee::setHoursWorked(float newHoursWorked = 0.0)
{
    hoursWorked = newHoursWorked;
} // end of setHoursWorked()
// getter for the employee ID
int Employee::getID()
{
	return ID;
} // end of getID()
//getter for the employee name
string Employee::getName()
{
    return name;
} // end of getName()
// getter for the hourly pay
float Employee::getHourlyPay()
{
    return hourlyPay;    
} // end of getHourlyPay()
// getter for the number of dependant
int Employee::getDependant()
{
    return dependant;    
}//end of getDependant()
// getter for the employeeType
int Employee::getEmployeeType()
{
    return employeeType;    
}//end og getEmployeeType()
// getter for the gender
string Employee::getGender()
{
    return gender;    
}//end of getGender()
// getter for the hours worked
float Employee::getHoursWorked()
{
    return hoursWorked;    
} // end of getHoursWorked()
// getter for the gross pay
float Employee::getGrossPay()
{
	//Using if to calculate the gross pay base on employee type which is 0 for union and 1 for management
    if (employeeType = 0)
    {
	
		if(hoursWorked <= 40 )
        {
            return hourlyPay * hoursWorked;
        }
    	else 
        {
            return 40 * hourlyPay + 1.5 * (hoursWorked - 40) * hourlyPay;
        } 
	}
	else 
	{
		return hourlyPay * hoursWorked;
	}
} // end of getGrossPay()
//Getter for net pay
float Employee::getNetPay()
{
	return (getGrossPay() * 0.85) - (30 * getDependant());
}//end of getNetPay()

// function prototypes   
//To read info about employee  from file  
bool populateClass(Employee[], int &);
//to read info about hours worked by each employee
bool readHoursWorkedFile(Employee[], int);
// To print the result in a file
void printResult(Employee[], int);
//to search the hours worked by each employee, using their ID to find the data related to each ID
bool search(Employee [], int, int, int &);

//Main function
int main()
{
	// max number of employees
    int MAX_SIZE = 100; 
    // counter for number of employees in file
    int counter = 0;
    // array of Employee objects
    Employee emp[MAX_SIZE]; 
    
    // populate array of Employee objects
    if(!populateClass(emp, counter))
    {
        cout << "Can not open inputFile" << endl;
        return 1;
    } // end of function call
    
    // add the hours worked to each corresponding Employee object in the array
	if (!readHoursWorkedFile(emp, counter))
    {
        cout << "Can not open inputFile" << endl;
        return 1;
    }// end of function call
    
    // print each employee's data in a file
    printResult(emp, counter);
    
    return 0;
} // end of main()

// populateClass() will instantiate an array of Employee class objects one time for each line
bool populateClass(Employee empArray[], int &counter)
{
    int ID;
    char name[25];
    string gender; 
    int employeType;
    int dependant;
    float hourlyPay;
    
    ifstream inputFile("master.txt");
    
    //If there is no input file, display a message to that effect and return false
    if (!inputFile)
    {
        cout << "Can not open master file \"master.txt\"" << endl;
        return false;
    }//end of if
    
    //Read records from the file as long as there are records left to read
    while(!inputFile.eof())
    {    
        inputFile >> ID;
        //ingore one character between ID and name
        inputFile.ignore(); 
        inputFile.get(name, 25);
        inputFile >> hourlyPay;
        inputFile >> dependant;
        inputFile >> employeType;
        inputFile.ignore();
        inputFile >> gender;
    
        empArray[counter].set(ID, name, hourlyPay, dependant, employeType, gender);
                
        counter++; // increment the counter of number of employees in file
    }//end of while
    
    inputFile.close();
    return true;
} // end of populateClass()

// read data from file to sets the hours worked to the corresponding employee 
// object once there is an ID match
bool readHoursWorkedFile(Employee empArray[], int count)
{
	int ID;
	int counter;
    float hoursWorked;
    ifstream timeFile("trans10.txt");
    bool found = false;
    int foundPosition;
    
    //If there is no transe10.txt file, display a message to that effect and return false
    if (!timeFile)
    {
        cout << "Can not open the time file \"trans10.txt\"" << endl;
        return false;    
    }//end of if
    
    while(!timeFile.eof())
    {
    	
        timeFile >> ID >> hoursWorked;
        //Function to find the ID mached with the ID from master file
        found = search(empArray, count, ID, foundPosition);
        
        if(found)
        {
        	//using if/else to skip invalid hours worked
        	if (hoursWorked > 0)
        	{
        		empArray[foundPosition].setHoursWorked(hoursWorked);
        
            	found = false;	
			}
			else
			{
				counter++;
				cout << "ID Number " << ID << ":  NOT Valid Data " << endl; 
			}
            
        }
        else
        {
            cout << "ID Number " << ID << ":  NOT FOUND " << endl; 
        }
    }
    cout << "Total number of transactions that were processed correctly: " << count - counter << endl << endl;
  return true;
} // end of readHoursWorkedFile()
//Function to print the result in a file
void printResult(Employee empArray[] , int counter)
{
	ofstream outputFile;
	float tallyGross = 0;
	float tallyNet = 0;
    //print the column headers in the file 
	outputFile << fixed << showpoint << setprecision(2) << endl;
    outputFile.open("Payroll Report.txt", ios ::app);
	outputFile << setw(3) << left << "ID" << setw(26) << "Name" << setw(10) << "Tax" 
    		   << setw(14) << "Insurance" << setw(14) << "Gross pay" << setw(10) << "Net Pay" << endl;
    outputFile.close();
    //Print one line of output for each employee in the file
    for (int i=0; i < counter; i++)
    {
    	//If to check if hour worked is valid
		if (empArray[i].getHoursWorked()  > 0.0001 )
        {	
        outputFile.open("Payroll Report.txt", ios ::app);
		outputFile 
		    << setw(3) << left << empArray[i].getID() << setw(26)
            << empArray[i].getName() << "$"<<setw(9) 
            <<  empArray[i].getGrossPay() * 0.15 << "$" <<setw(13)
            << empArray[i].getDependant() * 30.00 << "$" << setw(13)
            << empArray[i].getGrossPay() << "$" <<setw(9)
            << empArray[i].getNetPay() << endl;
            tallyGross = tallyGross + empArray[i].getGrossPay() ;
            tallyNet = tallyNet + empArray[i].getNetPay();
            outputFile.close();
         }       
    }//end of for loop
    outputFile.open("Payroll Report.txt", ios ::app);
    outputFile << "\nTotal amount of gross pay: $" << tallyGross << "\nTotal amount of net pay:   $" << tallyNet << endl;
    outputFile.close();
} // end of printResult()
//Search to find ID in the file which is mached with ID from master file
bool search(Employee empArray[], int counter, int target, int &position)
{
	for (int i = 0; i < counter; i++)
	{
		if (empArray[i].getID() == target)
		{
			position = i;
			return true;
		}
	}
	return false;
} // end of search()
