/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Apr 18 2021
Assignment #:	Project 07
Status: 		Completed
Language:		C++
Help:           I usually use Class PowerPoint, ClassWorks projects, Book, and Google. 
-------------------------------------------------------------------------
Comment: This program will use struct to store student name and 3 grades.
The program dynamically allocate an array of the size that will be enter by user, so to initiate the number of students. 
Then calculate the letter grade for each student and also
the average of all students.
*/
#include <fstream> 
#include <iostream>
#include <iomanip>
#include <string>
#include <istream>
#include <conio.h>
using namespace std;
//using struct to store name and grades of students
struct Student
{
    string studentName;
    int testOne;
    int testTwo;
    int testThree;
    char letters;  
};
//To get number of Students
int getStudentNum (string );
// To get the name and test grades 
void getInfo(Student [], int, int);
//To print the result
void PrintResult(Student [], Student [], Student [], Student [], Student [],float, int);
//To find the letter grade for each student
void getLetter(Student[], Student[], Student[], Student[], int);
//To find the average of all students
float getAverage(Student [], Student[], Student [], int );
//main function
int main()
{
	cout << fixed << showpoint << setprecision(2) << endl;
	//Using constant int for the number of tests
	const int col = 3;
	float average;
	//Initially pointed to nullptr
	Student *students = nullptr;
	//To dynamically allocate an array
    int number = getStudentNum ("Enter number of students: " );
    students = new Student[number]; 
    getInfo(students, number, col);
    getLetter(students, students, students, students, number);
    average = getAverage(students, students, students, number);
    PrintResult(students, students, students, students, students, average, number);
    // Free dynamically allocated memory
    delete [] students;
    students = nullptr;
    
    system("PAUSE");
    return 0;
}//End of main()
//To find the average of all students
float  getAverage(Student test1[], Student test2[], Student test3[], int number)
{
	float average;
	float tallySum = 0;
	//Using for loop to calculate the sum of all grades of all students
	 for(int row = 0; row < number; row++)
	 {
	 	tallySum = tallySum + (test1[row].testOne + test2[row].testTwo  + test3[row].testThree ) ;
	 }
	 return average = tallySum / (number * 3);
}// End of getAverage()
//To find the letter grade for each student
void getLetter(Student test1[], Student test2[], Student test3[],  Student grades[], int number)
{
	for(int row = 0; row < number; row++)
	{
		if(((test1[row].testOne + test2[row].testTwo  + test3[row].testThree ) / 3 )>= 90)
		{
			grades[row].letters = 'A';	
		}
		else if(((test1[row].testOne + test2[row].testTwo  + test3[row].testThree ) / 3 ) >= 80)
		{
			grades[row].letters  = 'B';
		}
		else if(((test1[row].testOne + test2[row].testTwo  + test3[row].testThree  ) / 3 )>= 70)
		{
			grades[row].letters = 'C';
		}
		else if(((test1[row].testOne + test2[row].testTwo  + test3[row].testThree ) / 3 ) >= 60)
		{
			grades[row].letters = 'D';
		}
		else
		{
			grades[row].letters  = 'F';
		}
	}		
}//End of getLetter()
//To print the result		
void PrintResult(Student students[], Student test1[], Student test2[], Student test3[],  Student grades[], float average, int number)
{
	cout << "\nSummary\n---------------------------------------------------------\n";
	cout << left << setw(21) << "\nName" << setw(20) << "Grades" << setw(15) << "Letter grade" << endl;
	for(int rows = 0; rows < number; rows++)	
	{
		cout << left << setw(20) <<  students[rows].studentName << left << test1[rows].testOne << ", " << test2[rows].testTwo << ", "<< test3[rows].testThree << right << setw(15) << grades[rows].letters << endl;
			  	
	}
	cout << "_________________________________________________________\n";
	cout <<left << setw(21) << "Average" << average << endl << endl;
}//End of printResult()
// To get the name and test grades 
void getInfo(Student students[] , int number, int col)
{
	for(int row = 0; row < number; row++)
	{
		cout << "Student Number " << row + 1;
		cout << "\nEnter the student name: ";
    	cin.ignore();
    	cin.clear();
    	getline(cin, students[row].studentName);
    	// using for loop to check all of the characters of the string
    	for (int a = 0 ; a < students[row].studentName.length(); a++)
		{
			//while loop will check the size of the string and also if there is any numeric value
			while (isdigit (students[row].studentName[a]) || students[row].studentName.size() < 1  || students[row].studentName.size() > 31   )
			{ 
				cout << "Name should be between 1 to 30 charecters with no numbers\nEnter the student name: ";
				cin.ignore();
    			getline(cin, students[row].studentName) ;
			}	
		}
		cout << "Enter grade for test 1: ";
		cin >> students[row].testOne;
		//Using while loop the get only numbers between 0 to 110
		while (students[row].testOne < 0 || students[row].testOne > 110)
		{
			cout << "\nGrade should be between 0-110\n";
			cout << "Enter grade for test 1: ";
			cin >> students[row].testOne;
		}
		cout << "Enter grade for test 2: ";
		cin >> students[row].testTwo;
		while (students[row].testTwo < 0 || students[row].testTwo > 110)
		{
			cout << "\nGrade should be between 0-110\n";
			cout << "Enter grade for test 2: ";
			cin >> students[row].testTwo;
		}
		cout << "Enter grade for test 3: ";
		cin >> students[row].testThree;
		while (students[row].testThree < 0 || students[row].testThree > 110)
		{
			cout << "\nGrade should be between 0-110\n";
			cout << "Enter grade for test 3: ";
			cin >> students[row].testThree;
		}
		//Using if statement to sort the tests
		if (students[row].testOne > students[row].testTwo)
		{
        	std::swap(students[row].testOne , students[row].testTwo);
    	}
    	if (students[row].testOne > students[row].testThree)
		{	 
        	std::swap(students[row].testOne , students[row].testThree);
    	}
   		if (students[row].testTwo > students[row].testThree)
   		{  
        	std::swap(students[row].testTwo , students[row].testThree);
    	}	
	}	
}//End of getInfo()
//To get number of Students
int getStudentNum (string prompt)
{
	int num;
	cout << prompt;
   	cin >> num;
    while (num <=0)
    {
   		cout << "Please enter number greater than 0\n";
   		cin >> num;
    }
    return num;
}//End of getStudentNum()





