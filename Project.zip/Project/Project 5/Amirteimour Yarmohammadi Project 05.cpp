/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Apr 04 2021
Assignment #:	Project 05
Status: 		Completed
Language:		C++
Help:           I usually use Class PowerPoint, ClassWorks projects, Book, and Google. 
-------------------------------------------------------------------------
Comments: This program calculates the shipment price for packages in three categories: for Texas, out of Texas and out of the country.
There is a base brice base on the weight and also extra cost for out of Texas and out of country.
Program stores the cost of shipment base on the weight in an array and during the process uses them.
Program checks the following as well to either accept or reject a package:
*The package weight must not exceed 50 pounds.
*The package must not exceed 6 feet in length, width, or height.
*The girth of the package must not exceed 10 feet. The girth is the circumference around the two smallest sides
of the package. If side1, side2, and side3 are the lengths of the three sides, and largest is the largest of the
three sides, then the girth can be calculated using: girth = 2 * ( side1 + side2 + side3 - largest ).
At the end program calculate all costs an also packages that are accepted or rejected.
*/

#include <iostream>				// for cin, cout, endl
#include <iomanip>
#include <string>
using namespace std;
// declaration of function prototypes
const int VALUE = 15;
// To get the Command as char
char getCommand(string);
//To get the weight and sides
float getData(string);
//To calculates the cost
float transaction(char & , float &, float &, float &, float &, float &, int [], float []);
// to find the longest side
float getMax(float &, float &, float &);
//To find the fee from array base on the weight
float findFee(  int[], float & );
//To print the results
void printResult ( int & , int &, float &);
//Main function()
int main()
{
	//Variabales
	char command;
	int weight[VALUE] = {1, 2, 3, 5, 7, 10, 13, 16, 20, 25, 30, 35, 40, 45, 50};
	float shippingCost[VALUE] = {1.5, 2.1, 4, 6.75, 9.9, 14.95, 19.4, 24.2, 27.3, 31.9, 38.5, 43.5, 44.8, 47.4, 55.2};
	float packageWeight;
	int index;
	float sideOne;
	float sideTwo;
	float sideThree;
	float max;
	float cost;
	//To have 2 decimal for numbers
	cout << fixed << showpoint << setprecision(2) << endl;
	cout << "                WELCOME TO AMIR SHIPPING SERVICE\n";
	cout << "\nMENUE\n" << "*************************************************************\n";
	command = getCommand("Enter Location: (T)exas, (O)ut of state, (F)oreign, (X)it\nEnter package weight and 3 dimensions\n\nEnter Location: (T)exas, (O)ut of state, (F)oreign, (X)it: ");
	int count = 0;
	int accepted = 0;
	int noAccepted = 0;
	float tallyCost = 0;
	//Using while loop for command = T, O, and F
	while (command == 'T' || command == 'O' || command == 'F')
	{
		packageWeight = getData("Enter package weight: ");
		sideOne = getData("Enter side1: ");
		sideTwo = getData("Enter side2: ");
		sideThree = getData("Enter side3: ");
		count = count + 1;
		cout << "\nTransaction #" <<  count << endl;
		//To find the longest side
		max = getMax(sideOne, sideTwo, sideThree);
		//To calculate cost of shipment
		cost = transaction(command, sideOne, sideTwo, sideThree, max, packageWeight, weight, shippingCost );
		//Using if to check if a package accepted or not(If accepted the cost will be > 0) and then count them.
		if (cost > 0)
		{
			accepted = accepted + 1;
		}
		else
		{
			noAccepted = noAccepted + 1;
		}
		//To calculate the total cost
		tallyCost = tallyCost + cost;
		cout << "\nMENUE\n" << "*************************************************************\n";
		command = getCommand("Enter Location: (T)exas, (O)ut of state, (F)oreign, (X)it\nEnter package weight and 3 dimensions\n\nEnter Location: (T)exas, (O)ut of state, (F)oreign, (X)it: ");
	}
	// To print the result
	printResult (accepted, noAccepted, tallyCost);  
	
	system("PAUSE");
    return 0;
} // end of main()
//To print the results
void printResult ( int & accepted, int & noAccepted, float & tallyCost)
{
	cout << "\n*************************************************************\nTransaction is done\n";
	cout <<"Number of accepted packages:       " << accepted;
	cout <<"\nNumber of rejected packages:       " << noAccepted;
	cout << "\nTotal Cost:                        $"<< tallyCost << endl;
}//End of PrintResults()
////To calculates the cost
float transaction(char & command, float & side1, float & side2, float & side3, float & max, float & pWeight, int weight[], float shippingCost[] )
{
	
	float cost;
	float girth = 2 * ( side1 + side2 + side3 - max );
	int index;
		//Checking if the package is acceptable
		if (side1 <= 6 && side2 <= 6 && side3 <= 6 && girth <= 10 && pWeight <=50)
		{
			//This function is doing a search to find the price of package base on its weight from the array and then the index
			index = findFee(weight, pWeight);
			if (command == 'T')
			{
				cout << "Location:            Texas\n";
				//Using the index to find the base price
				cost = pWeight * shippingCost[index];
			}	
			else if (command == 'F')
			{
				cout << "Location:            Foreign\n";
				//Using the index to find the base price + $40 for foreign
				cost = (pWeight * shippingCost[index] ) + 40;
			}
			else 
			{
				cout << "Location:            Out of State\n";
				//Using the index to find the base price + $35 for out of Texas
				cost = (pWeight * shippingCost[index] ) + 35;
			}
			cout << "Status:              Accepted\n";
			cout << "Weight:              "<< pWeight << " lbs\n";
			cout <<"Cost:                $"<< cost << endl;
		}
		//If package not accepted with cost = 0
		else 
		{
			if (command == 'T')
			{
				cout << "Location:            Texas\n";
			}	
			else if (command == 'F')
			{
				cout << "Location:            Foreign\n";
			}
			else 
			{
				cout << "Location:            Out of State\n";
			}	
			cost = 0;
			cout << "Status:              Rejected\n";
			cout << "Weight:              "<< pWeight << " lbs\n"; 
			cout <<"Cost:                "<< "N/A" << endl;	
		}
	return cost;
}//End of transaction()
//This function search for the weight that user input in the array to find the related price
float findFee( int weight[], float  & pWeight)
{
    int  first = 0;              // First array element
    int last = VALUE - 1;        // Last array element
    int middle;                // Midpoint of search
    int position = -1;          // Position of search value
    bool found = false;          // Flag to indicate if the value was found

     while (!found && first <= last)
     {
         middle = (first + last) / 2;             // Calculate midpoint
         if ( pWeight > weight[middle - 1]  &&   pWeight <= weight[middle])              // If value is found there
         {
            found = true;                        
            position = middle;
         }
         else if (weight[middle] > pWeight)         // If value is in lower half
            last = middle - 1;
         else
            first = middle + 1;                 // If value is in upper half
      }
      return position;
}//End of findFee()
//To find the longest side of the package
float getMax(float & side1, float & side2, float & side3)
{
	float max = side1;
	if (max < side2)
	{ 
		max = side2;
	}
	if (max < side3)
	{
		max = side3;
	}
	return max;
}//End of getMax()
//To get the wight and sides of the package
float getData(string prompt)
{
	float value;
	cout << prompt;
	cin >> value;
	while (value <= 0)
	{
		cout << "Please enter greater than zero amount\n";
		cin >> value;
	}
	
	return value;
}//End of getData()
//To get the command (T, O, F, and X)
char getCommand(string prompt)
{
	char command;
	cout << prompt;
	cin >> command; // pre-read
	command = toupper(command);
	cin.ignore();
	cin.clear(); 
	fflush(stdin);
	//Using while to only get the right command
	while (command != 'T' && command != 'O' && command != 'F' && command != 'X')
	{
		cout << "Wrong Entery\n" << endl;
		cout << prompt;
		cin >> command; // update-read
		command = toupper(command);
		cin.ignore();
		cin.clear(); 
		fflush(stdin);
	}
	
	return command;
} // end of getCommand()

