/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Mar 21 2021
Assignment #:	Project 03
Language:		C++
Status: 		Completed
-------------------------------------------------------------------------
Comments:
This program balance a checkbook at the end of the month.
The program will have the user enter the initial balance followed by a series of transactions. 
For each transaction, first  the user enter a transaction type. The valid transaction types are:
C - process a check.
D - process a deposit.
E - perform end of month processing and exit the program.
For checks and deposits, the user will be prompted to enter the transaction amount.
*/

#include <iostream>	
#include <iomanip>
#include <string>
#include <conio.h>
#include <stdio.h>
using namespace std;

// declaration of function prototypes
float getInicialBalance(string);
char getCommand(string);

//main()
int main()
{
	
	// decleration of variables
	// to add two decimal to the numbers
	cout<< fixed << setprecision(2);        
    float initialBalance;
    char command;
    float amount;
	float tallyBalance;
	float serviceCharge;
	float negative;
	float endBalance;
	int count;
	
    //This function will get the initial balance
    initialBalance = getInicialBalance("Please Enter Your Initial Balance: "); 
	cout << "Please Enter \n(D) Folloving by Amount for Deposit \n(C) Folloving by Amount for Check \n(E) Folloving by 0 for Exit \n"; 
    // pre-read
    command = getCommand("\nEnter a Transaction: ");
	cin.ignore();
	cin >> amount;
	command = toupper(command);
	// using while to make sure that user enter the right command
	while (command != 'D' && command != 'E' && command != 'C' || amount < 0)
		{
			cout << "Wrong Entery" << endl;
			command = getCommand("\nEnter a Transaction: ");
			cin.ignore();
			cin >> amount;
		}
	tallyBalance = initialBalance;
	serviceCharge = 0;
	negative = 0;
	count = 0;
		// using the loop with C or D until user enter E which is the end of the transaction
		while( command == 'D' || command == 'C')
		{
			 // Using if function to choose between D and C and their respective transaction
			if(command == 'D')
			{
				cout << "Processing Deposit for: $" << amount << endl;
				// Calculating the current balance after each transaction, using the while function
				tallyBalance = tallyBalance + amount;
				// using if to count the amount of time that balace falls below $500
				if (tallyBalance < 500)
				{
					count = count + 1;	
					cout << "If your Balace falls Below $500 Any Time During The Month, There Will Be a One Time Charge for $15\n";
					cout << "Total Transactions With Balance Below $500 is: " << count<< endl;
					cout << "Service Charge for Balance Below $500 is: $15" << endl;
				}
			
				cout << "\nProcessed...\n";
				cout << "Balance: $" << tallyBalance << endl;
				cout << "Total Service Charge: $" << serviceCharge << endl;
				cout << "-----------------------------------------------------------------------"<< endl;
			
			}
			else
			{
				cout << "Processing Check for: $" << amount << endl;
				// Calculating the current balance after each transaction, using the while function
				tallyBalance = tallyBalance - amount;
				// Calculating the service after each transaction, using the while function
				serviceCharge = serviceCharge + 0.35;
				cout << "\nProcessed...\n";
				// using if to count the amount of time that balace falls below $0
				if (tallyBalance < 0)
				{
					negative = negative + 35;
					cout << "Service Charge for Negative Balance: $" << negative << endl;					
				}
				// using if to count the amount of time that balace falls below $500
				if ( tallyBalance <500 )
				{
					count = count + 1;
					cout << "If your Balace falls Below $500 Any Time During The Month, There Will Be a One Time Charge for $15\n";
					cout << "Total Transactions With Balance Below $500 is: " << count<< endl;
					cout << "Service Charge for Balance Below $500 is: $15" << endl;
				}
				
				cout << "Balance: $" << tallyBalance << endl;
				cout << "Total Service Charge for Check: $" << serviceCharge << endl;
				cout << "-----------------------------------------------------------------------"<< endl;
			}
			cout << "Please Enter \n(D) Folloving by Amount for Deposit \n(C) Folloving by Amount for Check \n(E) Folloving by 0 for Exit \n"; // pre-read
        	command = getCommand("\nEnter a Transaction: ");
			cin.ignore();
			cin >> amount;
        	// using while to make sure that user enter the right command
			while (command != 'D' && command != 'E' && command != 'C' || amount < 0)
			{
		  		cout << "Wrong Entery" << endl;
		  		command = getCommand("\nEnter a Transaction: ");
	 	  		cin.ignore();
	   	  		cin >> amount;
			}
		}
	// Using if to check if the ballance falls bellow $500 at lease once  during the month then calculate end of month balance.
	if (count > 0)
	{
		// Calculating the End of the month balance 
		endBalance = tallyBalance - serviceCharge - negative - 15; 	
	}
	else
	{
		// Calculating the End of the month balance 
		endBalance = tallyBalance - serviceCharge - negative;
	}
	cout << "Transaction Is Done" << endl;
	cout << "Your Service Charge for Checks and Negative Balance Is: $" << serviceCharge + negative << endl;
	if (count > 0)
	{
		cout << "Total Transactions With Balance Below $500 is: " << count<< endl;
		cout << "Service Charge for Balance Below $500 is: $15" << endl;
	}
	cout << "Your End of the Month Balance Is: $" << endBalance << endl;
	cout << "-----------------------------------------------------------------------"<< endl;
		
	
    system("PAUSE");
    return 0;
    
} // end of main()

////This function will get the initial balance
float getInicialBalance(string prompt)    
{
	float balance;
	cout << prompt ;
	cin >> balance;
	cout << "You Entered: $" << balance << endl;
	// using while to check if the number is negetive
	while (balance < 0)                                
	{
		cout << "Please Enter 0 or a Positive Number"<< endl;
		cin >> balance;
		cout << "You Entered: $" << balance << endl;
	}
	cout<<"Your Initial Balance is: $" << balance <<endl;   
	cout << "-----------------------------------------------------------------------"<< endl;
	return balance;
}  //End of getInicialBalance

// This function will get the letter part of the command from user and change it to upper case
char getCommand(string prompt)
{
	char command;
	cout << prompt;
	cin >> command;
	command = toupper(command);
	return command;
} // end of getCommand()
