/* 
Name:     		Amirteimour Yarmohammadi
Date: 			Apr 15 2021
Assignment #:	Project 06
Status: 		Completed
Language:		C++
Help:           I usually use Class PowerPoint, ClassWorks projects, Book, and Google. 
-------------------------------------------------------------------------
Comment: This program will use struct to store master data for employee and also time sheet data for hours worke for employee.
all data then will be used to reat a report that has all the information about each employee pluse the payroll information
*/
#include <fstream> 
#include <iostream>
#include <iomanip>
#include <string>
#include <istream>
#include <conio.h>
using namespace std;
//using struct to store all master info about each employee
struct Employee
{
    int IDNum;
    string employeeName;
    float payRate;
    //to see if employee is union or not union
    int employeeType; 
};
//using struct to store all Timesheet info about each employee
struct Hours
{
	float employeeHours;
};
//to get employee master information
void getEmployeeData(Employee [], int);
//to get hours worked by employees
void getEmployeeHours (Hours[],  Employee [],  int);
// to calculate tax, netPay , GrossPay and print all the information
void getPay(Hours[], Employee [], Employee [] , Employee [], int );
//main function
int main()
{
	cout << fixed << showpoint << setprecision(2) << endl;
    const int TOTAL_EMPLOYEES = 4;
    Employee employees[TOTAL_EMPLOYEES];
    Hours hour[TOTAL_EMPLOYEES];
    getEmployeeData(employees,  TOTAL_EMPLOYEES);
    getEmployeeHours (hour, employees, TOTAL_EMPLOYEES);
    getPay(hour,employees, employees, employees,  TOTAL_EMPLOYEES);
    
    system("PAUSE");
    return 0;
}//end of main()
// to calculate tax, netPay , GrossPay and print all the information
void getPay(Hours hour[], Employee rate[], Employee id[] , Employee name[], int SIZE)
{
	float pay[SIZE];
	float tax[SIZE];
	float netPay[SIZE];
	float tallyGross = 0;
	float tallyNet = 0;
	//using for loop to calculate tax, netPay, grossPay, tallyGross and tallyNet
	for(int rows = 0; rows < SIZE; rows++)	
	 {
	 		if ( hour[rows].employeeHours <= 40)
	 		{
	 			pay[rows] = hour[rows].employeeHours * rate[rows].payRate;
			}
    		else
    		{
    			pay[rows] = ((hour[rows].employeeHours - 40 ) * (rate[rows].payRate * 1.5)) + (40 * rate[rows].payRate);
			}
    		tax[rows] = pay[rows] * 0.15; 
    		netPay[rows] =pay[rows] - tax[rows] ;	
    		tallyGross = tallyGross + pay[rows];
    		tallyNet = 	tallyNet + netPay[rows];
	}
	cout << "Payroll Report\n";
	cout << left << setw(10) <<"ID" << setw (20 ) << "Name" << setw (12 ) <<  "Gross Pay" << 
	setw (10 ) << "Tax" << setw (10 ) <<  "Net Pay" << endl; 
	//using for loop to print a table that has the information about  tax, netPay, grossPay
	for(int rows = 0; rows < SIZE; rows++)	
	 {
    	cout << left << setw(10) << id[rows].IDNum << setw(20) << name[rows].employeeName << setw(12) << 
		pay[rows] << setw (10 )<<tax[rows] <<setw (10 )<< netPay[rows];			
		cout <<'\n' ;
	}
	cout <<"\nTotal Gross Pay: $" << tallyGross << 
	       "\nTotal Net Pay:   $" << tallyNet << endl;	
}//end of getPay()
//to get hours worked by employees
void getEmployeeHours (Hours hour[] ,Employee empl[], int SIZE)
{
	cout << "\nTimesheet information\n\n";
	//using for loop to get data for each employee
	for(int i = 0; i < SIZE; i++)
	{
		cout <<  "Hours worked for "<<  empl[i].employeeName << " : ";
		cin >> hour[i].employeeHours;
		//using while to check the input
		while (hour[i].employeeHours <= 0 || hour[i].employeeHours > 84 )
			{ 
			cout << "Enter number between  1 to 84 for hours of work\n";
			cout <<  "Hours worked for "<<  empl[i].employeeName << " : ";
			cin >> hour[i].employeeHours;
			}
	}
	cout << "*****************************************************************\n";
}//end of getEmployeeHours()
//to get employee master information such as ID, name, payRate and union or not union
void getEmployeeData(Employee empl[], int SIZE)
{
	cout << "Employee Master information\n";
	//using for loop to get data for each employee
    for(int i = 0; i < SIZE; i++)
    {
        cout << "\nEnter data for employee " << i+1 << endl;
        
        cout << "Enter the employee ID: ";
        cin >> empl[i].IDNum;
        //using while to prevent user from intering numbers <= 0
        while (empl[i].IDNum <= 0  )
			{ 
			cout << "Enter number > 0\nEnter the employee ID: ";
			cin >>  empl[i].IDNum;
			}
			
        cout << "Enter the employee name: ";
        cin.ignore();
        cin.clear();
        getline(cin, empl[i].employeeName);
        // using for loop to check all of the characters of the string
        for (int a = 0 ; a < empl[i].employeeName.length(); a++)
		{
			//while will check the size of the string and also if there is any numeric value
			while (isdigit (empl[i].employeeName[a]) || empl[i].employeeName.size() < 1  || empl[i].employeeName.size() > 21   )
			{ 
			 	cout << "Name should be between 1 to 20 charecters with no numbers\nEnter the employee name: ";
			 	cin.ignore();
    		 	getline(cin, empl[i].employeeName) ;
			}	
		}
        cout << "Enter the employee pay rate: ";
        cin >>  empl[i].payRate;
        //using while to prevent user from intering numbers <= 0
		while (empl[i].payRate < 0  )
		{ 
			cout << "Enter number > 0\nEnter the employee pay rate: ";
			cin >>  empl[i].payRate;
		}	
        cout << "Enter the employee type:(0 for Union and 1 for Management) ";
        cin >> empl[i].employeeType; 
        //using while to prevent user from intering numbers beside 1 and 0
        while (empl[i].employeeType != 1 && empl[i].employeeType != 0)
		{
    		cout << "Enter the employee type:(0 for Union and 1 for Management) ";
    		cin >> empl[i].employeeType;
		} 
    }
    cout << "*****************************************************************";
}// end of getEmployeeData()